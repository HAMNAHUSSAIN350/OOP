#include <iostream>
#include <fstream>
using namespace std;
int main() {
    int n;
    cout << "Enter number" << endl;
    cin >> n;
    ofstream myfile("hamna.txt");
    myfile << n << endl;
    myfile.close();
    ifstream readfile("hamna.txt");
    if (readfile.is_open()) {
        string line;
        while (getline(readfile, line)) {
            cout << "Contents of the file: " << line << endl;
        }
        readfile.close();
    } else {
        cout << "Unable to open file" << endl;
    }

    return 0;
}